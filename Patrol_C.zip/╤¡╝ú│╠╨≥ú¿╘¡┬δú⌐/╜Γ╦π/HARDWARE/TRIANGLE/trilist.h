#ifndef __TRILIST_H
#define __TRILIST_H

#include<stdio.h>
#include<math.h>

void sanjiaohanshu(int i);

#endif

